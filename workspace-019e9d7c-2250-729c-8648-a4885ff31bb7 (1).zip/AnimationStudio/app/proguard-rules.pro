# SoCreate ProGuard Rules

# Application
-keep class com.socreate.** { *; }
-keepclassmembers class com.socreate.** { *; }

# Serialization
-keepattributes *Annotation*, InnerClasses
-dontnote kotlinx.serialization.AnnotationsKt
-keepclassmembers class kotlinx.serialization.json.** { *** Companion; }
-keepclasseswithmembers class kotlinx.serialization.json.** { kotlinx.serialization.KSerializer serializer(...); }
-keep,includedescriptorclasses class com.socreate.**$$serializer { *; }
-keepclassmembers class com.socreate.** { *** Companion; }
-keepclasseswithmembers class com.socreate.** { kotlinx.serialization.KSerializer serializer(...); }

# Compose
-keepclassmembers class * { @androidx.compose.runtime.Composable <methods>; }

# Coroutines
-keepnames class kotlinx.coroutines.internal.MainDispatcherFactory {}
-keepnames class kotlinx.coroutines.CoroutineExceptionHandler {}

# Room
-keep class * extends androidx.room.RoomDatabase
-keep @androidx.room.Entity class *
