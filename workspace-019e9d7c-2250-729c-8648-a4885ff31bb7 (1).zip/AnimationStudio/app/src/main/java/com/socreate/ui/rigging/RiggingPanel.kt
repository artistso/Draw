package com.socreate.ui.rigging

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.socreate.ui.screens.StudioViewModel
import com.socreate.ui.theme.*

data class RigBone(
    val id: String, val name: String, val parentId: String?,
    val fromX: Float, val fromY: Float, val toX: Float, val toY: Float,
    val length: Float, val angle: Float = 0f
)

data class RigJoint(
    val id: String, val name: String, val x: Float, val y: Float,
    val isEndpoint: Boolean = false
)

data class CharacterRig(
    val bones: List<RigBone> = emptyList(),
    val joints: List<RigJoint> = emptyList(),
    val ikTargets: List<RigJoint> = emptyList()
) {
    companion object {
        fun createHumanoid(cx: Float, cy: Float, bodyH: Float, bodyW: Float): CharacterRig {
            val head = RigJoint("j0", "Head", cx, cy - bodyH * 0.35f, true)
            val neck = RigJoint("j1", "Neck", cx, cy - bodyH * 0.25f)
            val spine = RigJoint("j2", "Spine", cx, cy)
            val hip = RigJoint("j3", "Hip", cx, cy + bodyH * 0.15f)
            val lShoulder = RigJoint("j4", "L Shoulder", cx - bodyW * 0.15f, cy - bodyH * 0.18f)
            val rShoulder = RigJoint("j5", "R Shoulder", cx + bodyW * 0.15f, cy - bodyH * 0.18f)
            val lElbow = RigJoint("j6", "L Elbow", cx - bodyW * 0.2f, cy + bodyH * 0.05f)
            val rElbow = RigJoint("j7", "R Elbow", cx + bodyW * 0.2f, cy + bodyH * 0.05f)
            val lWrist = RigJoint("j8", "L Wrist", cx - bodyW * 0.22f, cy + bodyH * 0.2f, true)
            val rWrist = RigJoint("j9", "R Wrist", cx + bodyW * 0.22f, cy + bodyH * 0.2f, true)

            val joints = listOf(head, neck, spine, hip, lShoulder, rShoulder, lElbow, rElbow, lWrist, rWrist)

            val bones = listOf(
                RigBone("b0", "Spine", null, hip.x, hip.y, spine.x, spine.y, 60f),
                RigBone("b1", "Neck", "b0", spine.x, spine.y, neck.x, neck.y, 40f),
                RigBone("b2", "Head", "b1", neck.x, neck.y, head.x, head.y, 30f),
                RigBone("b3", "L Clavicle", "b1", neck.x, neck.y, lShoulder.x, lShoulder.y, 25f),
                RigBone("b4", "R Clavicle", "b1", neck.x, neck.y, rShoulder.x, rShoulder.y, 25f),
                RigBone("b5", "L UpperArm", "b3", lShoulder.x, lShoulder.y, lElbow.x, lElbow.y, 35f),
                RigBone("b6", "L Forearm", "b5", lElbow.x, lElbow.y, lWrist.x, lWrist.y, 30f),
                RigBone("b7", "R UpperArm", "b4", rShoulder.x, rShoulder.y, rElbow.x, rElbow.y, 35f),
                RigBone("b8", "R Forearm", "b7", rElbow.x, rElbow.y, rWrist.x, rWrist.y, 30f),
            )

            val ikTargets = listOf(lWrist, rWrist)
            return CharacterRig(bones, joints, ikTargets)
        }
    }
}

@Composable
fun RiggingPanel(vm: StudioViewModel) {
    Surface(
        shape = RoundedCornerShape(topStart = 16.dp, bottomStart = 16.dp),
        color = DeepSlate.copy(alpha = 0.9f),
        modifier = Modifier.width(240.dp).fillMaxHeight(0.5f)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text("RIGGING", fontSize = 10.sp, fontWeight = FontWeight.Bold,
                color = RoseRed, letterSpacing = 1.sp)

            Spacer(Modifier.height(8.dp))

            Button(
                onClick = {
                    // Auto-rig from current strokes
                    vm.activeRig = CharacterRig.createHumanoid(
                        cx = 960f, cy = 540f, bodyH = 500f, bodyW = 300f
                    )
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = RoseRed)
            ) {
                Text("🦴 Auto-Rig Character", fontSize = 11.sp)
            }

            Spacer(Modifier.height(6.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TextButton(onClick = { vm.activeRig = null }) {
                    Text("Hide Rig", fontSize = 9.sp)
                }
                TextButton(onClick = { /* Add bone */ }) {
                    Text("+ Bone", fontSize = 9.sp)
                }
                TextButton(onClick = { /* Add IK */ }) {
                    Text("+ IK", fontSize = 9.sp)
                }
            }

            Spacer(Modifier.height(8.dp))

            // Show active rig info
            vm.activeRig?.let { rig ->
                Text("Bones: ${rig.bones.size}", fontSize = 9.sp, color = TextSecondary)
                Text("Joints: ${rig.joints.size}", fontSize = 9.sp, color = TextSecondary)
                Text("IK Targets: ${rig.ikTargets.size}", fontSize = 9.sp, color = TextSecondary)

                Spacer(Modifier.height(6.dp))

                LazyColumn {
                    itemsIndexed(rig.bones) { _, bone ->
                        Text(bone.name, fontSize = 9.sp, color = TextPrimary,
                            modifier = Modifier.padding(vertical = 2.dp))
                    }
                }
            }
        }
    }
}
