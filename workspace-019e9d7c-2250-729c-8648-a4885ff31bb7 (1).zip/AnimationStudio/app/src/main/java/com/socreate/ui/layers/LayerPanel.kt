package com.socreate.ui.layers

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.socreate.engine.AnimationLayer
import com.socreate.ui.screens.StudioViewModel
import com.socreate.ui.theme.*

@Composable
fun LayerPanel(vm: StudioViewModel) {
    Surface(
        shape = RoundedCornerShape(topEnd = 16.dp, bottomEnd = 16.dp),
        color = DeepSlate.copy(alpha = 0.9f),
        modifier = Modifier.width(220.dp).fillMaxHeight(0.5f)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text("LAYERS", fontSize = 10.sp, fontWeight = FontWeight.Bold,
                color = EmeraldGreen, letterSpacing = 1.sp)
            Spacer(Modifier.height(8.dp))

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                itemsIndexed(vm.layers) { index, layer ->
                    LayerRow(
                        layer = layer,
                        isSelected = index == vm.currentLayerIndex,
                        onSelect = { vm.currentLayerIndex = index },
                        onToggleVisibility = {
                            vm.layers.toMutableList().also {
                                it[index] = layer.copy(visible = !layer.visible)
                            }.let { /* would update state */ }
                        }
                    )
                }
            }

            Spacer(Modifier.height(4.dp))
            TextButton(onClick = { /* add layer */ },
                modifier = Modifier.fillMaxWidth()) {
                Text("+ Add Layer", fontSize = 10.sp, color = EmeraldGreen)
            }
        }
    }
}

@Composable
fun LayerRow(
    layer: AnimationLayer,
    isSelected: Boolean,
    onSelect: () -> Unit,
    onToggleVisibility: () -> Unit
) {
    Surface(
        onClick = onSelect,
        shape = RoundedCornerShape(8.dp),
        color = if (isSelected) EmeraldGreen.copy(alpha = 0.15f) else Color.Transparent,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                if (layer.visible) "●" else "○",
                fontSize = 12.sp,
                color = if (layer.visible) EmeraldGreen else TextMuted,
                modifier = Modifier.clickable { onToggleVisibility() }
            )
            Text(layer.name, fontSize = 11.sp, color = TextPrimary,
                modifier = Modifier.weight(1f))
            if (layer.locked) Text("🔒", fontSize = 10.sp)
        }
    }
}
