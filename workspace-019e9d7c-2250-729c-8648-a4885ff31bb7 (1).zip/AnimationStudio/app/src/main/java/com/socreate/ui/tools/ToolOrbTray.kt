package com.socreate.ui.tools

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.socreate.engine.DrawingTool
import com.socreate.ui.screens.StudioViewModel
import com.socreate.ui.theme.*
import kotlin.math.*

/**
 * 7 Orb hubs at the bottom — tap to expand radial ring menus.
 * Color-coded by category. Spring-animated via Compose.
 */
@Composable
fun ToolOrbTray(
    vm: StudioViewModel,
    modifier: Modifier = Modifier
) {
    var expandedOrb by remember { mutableStateOf<String?>(null) }

    Row(
        modifier = modifier.padding(8.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        OrbButton("draw", PrimaryBlue, "◉", "Draw", expandedOrb == "draw") {
            expandedOrb = if (expandedOrb == "draw") null else "draw"
        }
        OrbButton("layers", EmeraldGreen, "⊞", "Layers", expandedOrb == "layers") {
            expandedOrb = if (expandedOrb == "layers") null else "layers"
            vm.showLayers = !vm.showLayers
        }
        OrbButton("time", TealAccent, "◎", "Time", expandedOrb == "time") {
            expandedOrb = if (expandedOrb == "time") null else "time"
        }
        OrbButton("onion", AmberGold, "◑", "Onion", expandedOrb == "onion") {
            expandedOrb = if (expandedOrb == "onion") null else "onion"
        }
        OrbButton("tween", CyanBright, "↻", "Tween", expandedOrb == "tween") {
            expandedOrb = if (expandedOrb == "tween") null else "tween"
        }
        OrbButton("mods", RoseRed, "⌘", "Mods", expandedOrb == "mods") {
            expandedOrb = if (expandedOrb == "mods") null else "mods"
        }
        OrbButton("socreate", SlateGray, "◈", "socreate", expandedOrb == "socreate") {
            expandedOrb = if (expandedOrb == "socreate") null else "socreate"
        }
    }

    // Expanded radial ring (shown above the orbs)
    AnimatedVisibility(
        visible = expandedOrb != null,
        enter = scaleIn(transformOrigin = TransformOrigin(0.5f, 1f)) + fadeIn(),
        exit = scaleOut(transformOrigin = TransformOrigin(0.5f, 1f)) + fadeOut()
    ) {
        when (expandedOrb) {
            "draw" -> DrawRadial(vm)
            "layers" -> {} // Handled by LayerPanel
            "time" -> TimeRadial(vm)
            "onion" -> OnionRadial(vm)
            "tween" -> TweenRadial(vm)
            "mods" -> {} // Handled by ModifierBar
            "socreate" -> SocreateRadial(vm)
        }
    }
}

@Composable
fun OrbButton(
    key: String, color: Color, icon: String, label: String,
    expanded: Boolean, onClick: () -> Unit
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier
                .size(48.dp)
                .shadow(if (expanded) 12.dp else 6.dp, CircleShape)
                .clip(CircleShape)
                .background(color)
                .clickable(onClick = onClick),
            contentAlignment = Alignment.Center
        ) {
            Text(icon, fontSize = 19.sp, color = Color.White)
        }
        Text(label, fontSize = 8.sp, color = TextSecondary,
            modifier = Modifier.padding(top = 4.dp))
    }
}

@Composable
fun DrawRadial(vm: StudioViewModel) {
    Surface(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
        shape = RoundedCornerShape(20.dp),
        color = DeepSlate,
        tonalElevation = 8.dp
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            // Tool buttons
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(
                    DrawingTool.BRUSH to "●",
                    DrawingTool.PENCIL to "◇",
                    DrawingTool.INK to "◆",
                    DrawingTool.AIRBRUSH to "○",
                    DrawingTool.ERASER to "◌",
                    DrawingTool.FILL to "▣",
                    DrawingTool.LASSO to "⬡",
                    DrawingTool.LIQUIFY to "〜"
                ).forEach { (tool, icon) ->
                    FilterChip(
                        selected = vm.currentTool == tool,
                        onClick = { vm.currentTool = tool },
                        label = { Text(icon, fontSize = 14.sp) },
                        modifier = Modifier.height(32.dp)
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
            // Size slider
            SliderWithLabel("SIZE", vm.brushSize, 1f..120f) { vm.brushSize = it }
            SliderWithLabel("HARD", vm.brushHardness * 100f, 10f..100f) {
                vm.brushHardness = it / 100f
            }
            SliderWithLabel("OPAC", vm.brushOpacity * 100f, 1f..100f) {
                vm.brushOpacity = it / 100f
            }
            SliderWithLabel("STAB", vm.stabilizer * 100f, 0f..100f) {
                vm.stabilizer = it / 100f
            }
        }
    }
}

@Composable
fun TimeRadial(vm: StudioViewModel) {
    Surface(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
        shape = RoundedCornerShape(20.dp),
        color = DeepSlate,
        tonalElevation = 8.dp
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            SliderWithLabel("FPS", vm.engine.state.fps.toFloat(), 4f..60f) {
                vm.engine.setFps(it.toInt())
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TextButton(onClick = { vm.addFrame() }) { Text("+ Frame") }
                TextButton(onClick = { vm.toggleKeyframe() }) { Text("◆ Keyframe") }
                TextButton(onClick = { vm.clearFrame() }) { Text("⌫ Clear") }
            }
        }
    }
}

@Composable
fun OnionRadial(vm: StudioViewModel) {
    Surface(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
        shape = RoundedCornerShape(20.dp),
        color = DeepSlate,
        tonalElevation = 8.dp
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            SliderWithLabel("COUNT", vm.engine.state.onionCount.toFloat(), 1f..6f) {
                vm.engine.setOnionCount(it.toInt())
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TextButton(onClick = { vm.engine.toggleOnion() }) {
                    Text(if (vm.engine.state.onionEnabled) "👁 ON" else "👁 OFF")
                }
            }
        }
    }
}

@Composable
fun TweenRadial(vm: StudioViewModel) {
    Surface(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
        shape = RoundedCornerShape(20.dp),
        color = DeepSlate,
        tonalElevation = 8.dp
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            // Easing selection and tween generation handled via ViewModel
            Text("Select keyframes (Shift+click) then tween",
                fontSize = 10.sp, color = TextSecondary)
        }
    }
}

@Composable
fun SocreateRadial(vm: StudioViewModel) {
    Surface(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
        shape = RoundedCornerShape(20.dp),
        color = DeepSlate,
        tonalElevation = 8.dp
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            TextButton(onClick = { /* Save project */ }) { Text("💾 Save") }
            TextButton(onClick = { /* Export */ }) { Text("📤 Export .socreate") }
        }
    }
}

@Composable
fun SliderWithLabel(
    label: String, value: Float, range: ClosedFloatingPointRange<Float>,
    onChange: (Float) -> Unit
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth()
    ) {
        Text(label, fontSize = 9.sp, color = TextSecondary, modifier = Modifier.width(36.dp))
        Slider(value = value, onValueChange = onChange, valueRange = range,
            modifier = Modifier.weight(1f).height(20.dp))
        Text("${value.toInt()}", fontSize = 9.sp, color = TextSecondary,
            modifier = Modifier.width(32.dp))
    }
}
