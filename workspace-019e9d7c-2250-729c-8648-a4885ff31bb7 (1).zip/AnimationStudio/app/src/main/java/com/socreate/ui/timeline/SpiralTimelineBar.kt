package com.socreate.ui.timeline

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.*
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.socreate.ui.screens.StudioViewModel
import com.socreate.ui.theme.*
import kotlin.math.*

/**
 * Spiral geodesic timeline — keyframes spiral outward from center.
 * Current frame is teal-glowing. Keyframes glow amber. Tweens glow cyan.
 * Drag to navigate. Shift+click for multi-select.
 */
@Composable
fun SpiralTimelineBar(
    vm: StudioViewModel,
    modifier: Modifier = Modifier
) {
    val cf = vm.currentFrame()
    val total = vm.totalFrames()

    Surface(
        modifier = modifier.fillMaxWidth().height(160.dp),
        color = DeepSlate.copy(alpha = 0.9f),
        shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp),
        tonalElevation = 8.dp
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Transport controls
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(onClick = { vm.goToFrame(0) }) { Text("⏮") }
                TextButton(onClick = { vm.goToFrame(cf - 1) }) { Text("◀") }
                IconButton(onClick = { vm.togglePlay() }) {
                    Text(if (vm.engine.state.isPlaying) "⏸" else "▶", fontSize = 20.sp)
                }
                TextButton(onClick = { vm.goToFrame(cf + 1) }) { Text("▶") }
                TextButton(onClick = { vm.goToFrame(total - 1) }) { Text("⏭") }

                Spacer(Modifier.width(12.dp))

                Text("FPS:", fontSize = 10.sp, color = TextSecondary)
                Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                    listOf(8, 12, 24, 30).forEach { fps ->
                        FilterChip(
                            selected = vm.engine.state.fps == fps,
                            onClick = { vm.engine.setFps(fps) },
                            label = { Text("$fps", fontSize = 9.sp) },
                            modifier = Modifier.height(22.dp)
                        )
                    }
                }

                Spacer(Modifier.width(8.dp))

                TextButton(onClick = { vm.addFrame() }) { Text("+ Frame", fontSize = 9.sp) }
                TextButton(onClick = { vm.toggleKeyframe() }) {
                    Text("◆ Key", fontSize = 9.sp, color = if (cf in vm.keyframes) AmberGold else TextSecondary)
                }

                Text(
                    "Frame ${cf + 1}/$total",
                    fontSize = 10.sp,
                    color = TextSecondary,
                    modifier = Modifier.padding(start = 8.dp)
                )
            }

            // Spiral canvas
            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .pointerInput(Unit) {
                        detectDragGestures { change, _ ->
                            val x = change.position.x
                            val cx = size.width / 2
                            // Map x position to frame index
                            val ratio = x / size.width
                            val frame = (ratio * total).toInt().coerceIn(0, total - 1)
                            vm.goToFrame(frame)
                        }
                    }
            ) {
                val cx = size.width / 2
                val cy = size.height / 2
                val baseR = 20f
                val spread = 9f

                for (i in 0 until total) {
                    val angle = (i.toFloat() / total) * PI.toFloat() * 4.5f - PI.toFloat() / 2
                    val r = baseR + i * spread
                    val x = cx + cos(angle) * r
                    val y = cy + sin(angle) * r

                    val isCurrent = i == cf
                    val isKey = i in vm.keyframes
                    val isTween = i in vm.tweenFrames
                    val isSel = i in vm.selectedFrames

                    val color = when {
                        isSel -> Color(0xFFff5c7a)
                        isCurrent -> TealAccent
                        isKey -> AmberGold.copy(alpha = 0.7f)
                        isTween -> CyanBright.copy(alpha = 0.6f)
                        else -> MidSurface
                    }

                    drawCircle(color, 9f, Offset(x, y))
                    if (isCurrent) {
                        drawCircle(TealAccent.copy(alpha = 0.3f), 18f, Offset(x, y))
                        drawCircle(TealAccent, 11f, Offset(x, y), style = Stroke(2f))
                    }
                    if (isKey) {
                        drawCircle(AmberGold.copy(alpha = 0.4f), 13f, Offset(x, y), style = Stroke(1.5f))
                    }
                    if (isSel) {
                        drawCircle(Color(0xFFff5c7a).copy(alpha = 0.3f), 15f, Offset(x, y), style = Stroke(2f))
                    }
                }
            }
        }
    }
}
