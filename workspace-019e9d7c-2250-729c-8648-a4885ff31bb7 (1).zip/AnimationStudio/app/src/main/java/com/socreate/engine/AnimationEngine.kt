package com.socreate.engine

import androidx.compose.ui.geometry.Offset
import kotlin.math.*

/**
 * Core animation engine — frame management, onion skinning,
 * tweening interpolation, playback control.
 */
class AnimationEngine {

    data class EngineState(
        val currentFrame: Int = 0,
        val totalFrames: Int = 24,
        val fps: Int = 12,
        val isPlaying: Boolean = false,
        val loop: Boolean = true,
        val onionEnabled: Boolean = true,
        val onionCount: Int = 2,
        val onionPrevColor: Long = 0xFF3b82f6,
        val onionNextColor: Long = 0xFFef4444
    )

    var state = EngineState()
        private set

    fun getOnionFrames(): List<OnionFrame> {
        if (!state.onionEnabled) return emptyList()
        val result = mutableListOf<OnionFrame>()
        for (o in 1..state.onionCount) {
            val prev = if (state.loop) (state.currentFrame - o + state.totalFrames) % state.totalFrames
                       else (state.currentFrame - o).coerceAtLeast(0)
            val next = if (state.loop) (state.currentFrame + o) % state.totalFrames
                       else (state.currentFrame + o).coerceAtMost(state.totalFrames - 1)
            val opacity = 1f - (o.toFloat() / (state.onionCount + 1))
            result.add(OnionFrame(prev, opacity * 0.35f, state.onionPrevColor, true))
            if (next != state.currentFrame)
                result.add(OnionFrame(next, opacity * 0.35f, state.onionNextColor, false))
        }
        return result
    }

    fun goToFrame(i: Int) {
        state = state.copy(currentFrame = i.coerceIn(0, (state.totalFrames - 1).coerceAtLeast(0)))
    }

    fun addFrame() { state = state.copy(totalFrames = state.totalFrames + 1) }

    fun setFps(fps: Int) { state = state.copy(fps = fps.coerceIn(1, 60)) }

    fun toggleOnion() { state = state.copy(onionEnabled = !state.onionEnabled) }

    fun setOnionCount(n: Int) { state = state.copy(onionCount = n.coerceIn(1, 6)) }
}

data class OnionFrame(
    val frameIndex: Int,
    val opacity: Float,
    val tintColor: Long,
    val isBefore: Boolean
)

/**
 * Spring physics model for fluid UI animations
 */
class Spring(var position: Float = 0f, val stiffness: Float = 180f, val damping: Float = 14f) {
    var velocity: Float = 0f
    var target: Float = position

    fun step(dt: Float): Float {
        val force = -stiffness * (position - target)
        val dampForce = -damping * velocity
        velocity += (force + dampForce) * dt
        position += velocity * dt
        return position
    }

    fun set(t: Float) { target = t }
}
