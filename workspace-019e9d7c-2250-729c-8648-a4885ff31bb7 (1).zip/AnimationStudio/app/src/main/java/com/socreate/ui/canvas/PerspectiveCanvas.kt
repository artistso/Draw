package com.socreate.ui.canvas

import android.graphics.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.*
import androidx.compose.ui.input.pointer.*
import com.socreate.engine.*
import com.socreate.ui.screens.StudioViewModel
import kotlin.math.*

/**
 * The 3D Perspective Box Canvas.
 * Artists see a trapezoidal box showing foreground (wide), background (narrow),
 * side walls at natural angles, and a base plane for character placement.
 * Tools sit at the edges at angles natural to the artist's hand position.
 */
@Composable
fun PerspectiveCanvas(
    vm: StudioViewModel,
    modifier: Modifier = Modifier
) {
    var currentStroke by remember { mutableStateOf<List<StrokePoint>>(emptyList()) }
    var currentPressure by remember { mutableStateOf(1f) }
    var panOffset by remember { mutableStateOf(Offset.Zero) }
    var zoomScale by remember { mutableStateOf(1f) }

    Canvas(
        modifier = modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectTransformGestures { _, pan, zoom, _ ->
                    zoomScale = (zoomScale * zoom).coerceIn(0.15f, 8f)
                    panOffset += pan
                }
            }
            .pointerInput(vm.currentTool, vm.stylusOnly) {
                awaitPointerEventScope {
                    while (true) {
                        val event = awaitPointerEvent()
                        val change = event.changes.firstOrNull() ?: continue

                        // Stylus-only filtering
                        if (vm.stylusOnly && change.type != PointerType.Stylus) continue

                        val pos = change.position
                        val pressure = change.pressure.coerceIn(0.1f, 1f)

                        when {
                            change.pressed && currentStroke.isEmpty() -> {
                                currentStroke = listOf(
                                    StrokePoint(pos.x, pos.y, pressure, change.tilt)
                                )
                                currentPressure = pressure
                            }
                            !change.pressed && currentStroke.isNotEmpty() -> {
                                // Stabilize and commit
                                val stabilized = stabilizePoints(currentStroke, vm.stabilizer)
                                vm.addStroke(
                                    StrokeData(
                                        points = stabilized,
                                        colorArgb = vm.currentColor,
                                        strokeWidth = vm.brushSize * currentPressure,
                                        opacity = vm.brushOpacity,
                                        hardness = vm.brushHardness,
                                        tool = vm.currentTool.key,
                                        layerId = vm.currentLayerIndex,
                                        frameIndex = vm.currentFrame()
                                    )
                                )
                                currentStroke = emptyList()
                            }
                            currentStroke.isNotEmpty() -> {
                                currentStroke = currentStroke + StrokePoint(
                                    pos.x, pos.y, pressure, change.tilt
                                )
                                currentPressure = (currentPressure + pressure) / 2
                            }
                        }
                    }
                }
            }
    ) {
        val w = size.width
        val h = size.height

        // Apply zoom/pan
        withTransform({
            translate(w / 2, h / 2)
            scale(zoomScale, zoomScale, Offset.Zero)
            translate(-w / 2 + panOffset.x, -h / 2 + panOffset.y)
        }) {
            // 1. Draw the 3D Perspective Box
            if (vm.showPerspectiveBox) {
                drawPerspectiveBox(w, h, vm.perspectiveBoxDepth, vm.perspectiveBoxRotation)
            }

            // 2. Draw grid if enabled
            if (vm.showGrid) {
                drawGrid(w, h, vm.gridSize)
            }

            // 3. Draw onion skin frames
            val onionFrames = vm.engine.getOnionFrames()
            for (onion in onionFrames) {
                val strokes = vm.getStrokesForFrame(onion.frameIndex, vm.currentLayerIndex)
                for (s in strokes) {
                    drawStrokeData(s, onion.opacity, Color(onion.tintColor.toULong()))
                }
            }

            // 4. Draw current frame strokes (all visible layers)
            for ((li, layer) in vm.layers.withIndex()) {
                if (!layer.visible) continue
                val strokes = vm.getStrokesForFrame(vm.currentFrame(), li)
                for (s in strokes) {
                    drawStrokeData(s, s.opacity, Color(s.colorArgb.toULong()))
                }
            }

            // 5. Draw current in-progress stroke
            if (currentStroke.size >= 2) {
                drawCurrentStroke(currentStroke, vm.brushSize, vm.currentColor, vm.brushOpacity)
            }

            // 6. Draw selection bounding box
            vm.selectionBounds?.let { drawSelectionBox(it) }

            // 7. Draw active rig overlay
            vm.activeRig?.let { drawRigOverlay(it) }
        }

        // Side tools at natural hand angles
        drawSideTools(w, h)
    }
}

/**
 * Draw the 3D perspective box — a trapezoid showing foreground (wide base),
 * background (narrow), side walls, and ground plane.
 */
private fun DrawScope.drawPerspectiveBox(
    w: Float, h: Float, depth: Float, rotation: Float
) {
    val cx = w / 2
    val cy = h * 0.45f  // Horizon line slightly above center

    // Foreground (wide) and background (narrow) edges
    val fgHalf = w * 0.42f
    val bgHalf = w * 0.15f

    val fgY = h * 0.85f  // Foreground bottom
    val mgY = h * 0.65f  // Midground
    val bgY = h * 0.15f  // Background top

    // Trapezoid corners: foreground wide, background narrow
    val fgLeft = cx - fgHalf; val fgRight = cx + fgHalf
    val mgLeft = cx - bgHalf * 1.8f; val mgRight = cx + bgHalf * 1.8f
    val bgLeft = cx - bgHalf; val bgRight = cx + bgHalf

    // Horizon line
    drawLine(Color(0xFF404860), Offset(0f, cy), Offset(w, cy), 1.5f)

    // Back wall (narrow rectangle at top)
    val backWallPath = Path().apply {
        moveTo(bgLeft, bgY)
        lineTo(bgRight, bgY)
        lineTo(bgRight, mgY)
        lineTo(bgLeft, mgY)
        close()
    }
    drawPath(backWallPath, Color(0xFF1a1e30).copy(alpha = 0.5f))
    drawPath(backWallPath, Color(0xFF405070).copy(alpha = 0.2f), style = Stroke(1.5f))

    // Left wall (perspective lines converging to vanishing point)
    val leftWallPath = Path().apply {
        moveTo(bgLeft, bgY)
        lineTo(bgLeft, mgY)
        lineTo(fgLeft, fgY)
        lineTo(fgLeft, fgY - (fgY - mgY))
        close()
    }
    drawPath(leftWallPath, Color(0xFF222840).copy(alpha = 0.4f))
    drawPath(leftWallPath, Color(0xFF506080).copy(alpha = 0.2f), style = Stroke(1.5f))

    // Right wall
    val rightWallPath = Path().apply {
        moveTo(bgRight, bgY)
        lineTo(bgRight, mgY)
        lineTo(fgRight, fgY)
        lineTo(fgRight, fgY - (fgY - mgY))
        close()
    }
    drawPath(rightWallPath, Color(0xFF1e2438).copy(alpha = 0.4f))
    drawPath(rightWallPath, Color(0xFF506080).copy(alpha = 0.2f), style = Stroke(1.5f))

    // Ground plane (trapezoid from mid to foreground)
    val groundPath = Path().apply {
        moveTo(fgLeft, fgY)
        lineTo(fgRight, fgY)
        lineTo(mgRight, mgY)
        lineTo(mgLeft, mgY)
        close()
    }
    drawPath(groundPath, Color(0xFF1c2034).copy(alpha = 0.35f))
    drawPath(groundPath, Color(0xFF505878).copy(alpha = 0.15f), style = Stroke(1f))

    // Center line for symmetry
    drawLine(
        Color(0xFF505878).copy(alpha = 0.3f),
        Offset(cx, bgY), Offset(cx, fgY), 1f
    )

    // Vanishing point indicator
    drawCircle(Color(0xFFff5c7a).copy(alpha = 0.6f), 6f, Offset(cx, cy))
    drawCircle(Color.White.copy(alpha = 0.3f), 3f, Offset(cx, cy))

    // Labels
    drawContext.canvas.nativeCanvas.drawText(
        "FOREGROUND", fgLeft + 8, fgY - 8,
        android.graphics.Paint().apply {
            color = 0x40FFFFFF.toInt(); textSize = 22f; isFakeBoldText = true
        }
    )
    drawContext.canvas.nativeCanvas.drawText(
        "BACKGROUND", bgLeft + 8, bgY + 18,
        android.graphics.Paint().apply {
            color = 0x30FFFFFF.toInt(); textSize = 22f; isFakeBoldText = true
        }
    )
}

/**
 * Tool indicators along the side walls at natural hand angles.
 */
private fun DrawScope.drawSideTools(w: Float, h: Float) {
    val tools = listOf(
        Triple("BRUSH", Offset(w * 0.02f, h * 0.25f), 15f),
        Triple("ERASER", Offset(w * 0.02f, h * 0.38f), 15f),
        Triple("FILL", Offset(w * 0.02f, h * 0.51f), 15f),
        Triple("SELECT", Offset(w * 0.96f, h * 0.25f), 15f),
        Triple("LIQUIFY", Offset(w * 0.96f, h * 0.38f), 15f),
        Triple("GRID", Offset(w * 0.96f, h * 0.51f), 15f),
    )
    val paint = android.graphics.Paint().apply {
        color = 0x30FFFFFF.toInt(); textSize = 18f
    }
    for ((label, pos, _) in tools) {
        drawCircle(Color.White.copy(alpha = 0.08f), 18f, pos)
        drawCircle(Color.White.copy(alpha = 0.15f), 18f, pos, style = Stroke(1f))
        drawContext.canvas.nativeCanvas.drawText(label, pos.x - 16, pos.y + 6, paint)
    }
}

private fun DrawScope.drawGrid(w: Float, h: Float, gs: Float) {
    val alpha = 0.12f
    for (x in 0..w.toInt() step gs.toInt()) {
        drawLine(Color.White.copy(alpha = alpha), Offset(x.toFloat(), 0f), Offset(x.toFloat(), h), 0.5f)
    }
    for (y in 0..h.toInt() step gs.toInt()) {
        drawLine(Color.White.copy(alpha = alpha), Offset(0f, y.toFloat()), Offset(w, y.toFloat()), 0.5f)
    }
}

private fun DrawScope.drawStrokeData(s: StrokeData, opacity: Float, tint: Color) {
    if (s.points.size < 2) return
    val path = Path().apply {
        moveTo(s.points[0].x, s.points[0].y)
        for (i in 1 until s.points.size) {
            lineTo(s.points[i].x, s.points[i].y)
        }
    }
    drawPath(
        path, tint.copy(alpha = opacity * s.opacity),
        style = Stroke(width = s.strokeWidth, cap = StrokeCap.Round, join = StrokeJoin.Round)
    )
}

private fun DrawScope.drawCurrentStroke(
    pts: List<StrokePoint>, size: Float, color: Int, opacity: Float
) {
    if (pts.size < 2) return
    val path = Path().apply {
        moveTo(pts[0].x, pts[0].y)
        for (i in 1 until pts.size) {
            lineTo(pts[i].x, pts[i].y)
        }
    }
    drawPath(
        path, Color(color).copy(alpha = opacity),
        style = Stroke(width = size * (pts.lastOrNull()?.pressure ?: 1f), cap = StrokeCap.Round, join = StrokeJoin.Round)
    )
}

private fun DrawScope.drawSelectionBox(b: StudioViewModel.SelectionBounds) {
    drawRect(
        Color(0xFF5b8cff).copy(alpha = 0.15f),
        Offset(b.minX, b.minY),
        Size(b.maxX - b.minX, b.maxY - b.minY)
    )
    drawRect(
        Color(0xFF5b8cff),
        Offset(b.minX, b.minY),
        Size(b.maxX - b.minX, b.maxY - b.minY),
        style = Stroke(2f)
    )
}

private fun DrawScope.drawRigOverlay(rig: CharacterRig) {
    // Draw bones
    for (bone in rig.bones) {
        drawLine(
            Color(0xFFff5c7a).copy(alpha = 0.7f),
            Offset(bone.fromX, bone.fromY),
            Offset(bone.toX, bone.toY),
            3f
        )
    }
    // Draw joints
    for (joint in rig.joints) {
        drawCircle(Color(0xFF00c8ff), 6f, Offset(joint.x, joint.y))
        drawCircle(Color.White.copy(alpha = 0.5f), 4f, Offset(joint.x, joint.y))
    }
    // IK targets
    for (target in rig.ikTargets) {
        drawCircle(Color(0xFFf4a838), 10f, Offset(target.x, target.y), style = Stroke(2f))
        drawCircle(Color(0xFFf4a838).copy(alpha = 0.3f), 10f, Offset(target.x, target.y))
    }
}

fun stabilizePoints(pts: List<StrokePoint>, strength: Float): List<StrokePoint> {
    if (pts.size < 3 || strength <= 0f) return pts
    val result = pts.toMutableList()
    for (i in 1 until pts.size - 1) {
        val w = strength * 0.5f
        result[i] = StrokePoint(
            x = pts[i].x * (1 - w) + (pts[i - 1].x + pts[i + 1].x) / 2 * w,
            y = pts[i].y * (1 - w) + (pts[i - 1].y + pts[i + 1].y) / 2 * w,
            pressure = pts[i].pressure,
            tilt = pts[i].tilt
        )
    }
    return result
}
