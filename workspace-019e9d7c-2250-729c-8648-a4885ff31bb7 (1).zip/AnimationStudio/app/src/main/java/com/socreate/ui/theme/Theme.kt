package com.socreate.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

// SoCreate brand palette — professional, dark, modern
val InkBlack = Color(0xFF0a0a10)
val DeepSlate = Color(0xFF141822)
val DarkSurface = Color(0xFF1a1e2c)
val MidSurface = Color(0xFF222636)
val LightBorder = Color(0xFF303448)

val PrimaryBlue = Color(0xFF5b8cff)
val TealAccent = Color(0xFF00d4be)
val EmeraldGreen = Color(0xFF2cdd78)
val AmberGold = Color(0xFFf4a838)
val VioletPurple = Color(0xFF8e64f8)
val RoseRed = Color(0xFFff5c7a)
val CyanBright = Color(0xFF00c8ff)
val SlateGray = Color(0xFF8c9bac)

val TextPrimary = Color(0xFFe4e6f0)
val TextSecondary = Color(0xFFa2a6bc)
val TextMuted = Color(0xFF5e627a)

private val SoCreateDark = darkColorScheme(
    primary = PrimaryBlue,
    onPrimary = Color.White,
    primaryContainer = Color(0xFF1a3a80),
    secondary = TealAccent,
    onSecondary = Color.Black,
    secondaryContainer = Color(0xFF003d4c),
    tertiary = EmeraldGreen,
    background = InkBlack,
    surface = DeepSlate,
    surfaceVariant = MidSurface,
    onBackground = TextPrimary,
    onSurface = TextPrimary,
    onSurfaceVariant = TextSecondary,
    outline = LightBorder
)

@Composable
fun SoCreateTheme(content: @Composable () -> Unit) {
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            (view.context as? Activity)?.window?.let {
                it.statusBarColor = android.graphics.Color.TRANSPARENT
                it.navigationBarColor = android.graphics.Color.TRANSPARENT
            }
        }
    }
    MaterialTheme(colorScheme = SoCreateDark, content = content)
}
