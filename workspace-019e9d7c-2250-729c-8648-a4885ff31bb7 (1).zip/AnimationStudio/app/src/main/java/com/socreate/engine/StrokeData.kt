package com.socreate.engine

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.toArgb
import kotlinx.serialization.Serializable

@Serializable
data class StrokePoint(
    val x: Float,
    val y: Float,
    val pressure: Float = 1f,
    val tilt: Float = 0f
) {
    fun toOffset() = Offset(x, y)
}

@Serializable
data class StrokeData(
    val points: List<StrokePoint> = emptyList(),
    val colorArgb: Int = Color.Black.toArgb(),
    val strokeWidth: Float = 8f,
    val opacity: Float = 1f,
    val hardness: Float = 0.8f,
    val tool: String = "BRUSH",
    val layerId: Int = 0,
    val frameIndex: Int = 0
) {
    fun toPath(): Path = Path().apply {
        if (points.isEmpty()) return@apply
        moveTo(points.first().x, points.first().y)
        for (i in 1 until points.size) {
            val xc = (points[i].x + points.getOrNull(i + 1)?.x ?: points[i].x) / 2
            val yc = (points[i].y + points.getOrNull(i + 1)?.y ?: points[i].y) / 2
            quadraticTo(points[i].x, points[i].y, xc, yc)
        }
        close()
    }
}

@Serializable
data class AnimationLayer(
    val id: Int = 0,
    val name: String = "Layer",
    val visible: Boolean = true,
    val locked: Boolean = false,
    val opacity: Float = 1f,
    val blendMode: String = "NORMAL",
    val frames: MutableMap<Int, MutableList<StrokeData>> = mutableMapOf()
) {
    fun getStrokes(frame: Int): List<StrokeData> = frames[frame] ?: emptyList()

    fun addStroke(frame: Int, stroke: StrokeData) {
        frames.getOrPut(frame) { mutableListOf() }.add(stroke)
    }

    fun clearFrame(frame: Int) { frames.remove(frame) }
}

enum class DrawingTool(val key: String) {
    BRUSH("brush"), PENCIL("pencil"), INK("ink"),
    AIRBRUSH("airbrush"), ERASER("eraser"), FILL("fill"),
    LASSO("lasso"), LIQUIFY("liquify"), MOVE("move")
}
