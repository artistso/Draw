package com.socreate.ui.tools

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.socreate.ui.screens.StudioViewModel
import com.socreate.ui.theme.*

/**
 * Dedicated Shift, Ctrl, Alt toggle bar — always visible, always accessible.
 * Plus Undo/Redo. Designed for the animator's non-drawing hand.
 */
@Composable
fun ModifierBar(
    vm: StudioViewModel,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        color = DeepSlate.copy(alpha = 0.85f),
        tonalElevation = 6.dp
    ) {
        Column(
            modifier = Modifier.padding(6.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            ModifierToggle("⇧", "Shift", vm.shiftHeld, { vm.shiftHeld = !vm.shiftHeld }, RoseRed)
            ModifierToggle("⌃", "Ctrl", vm.ctrlHeld, { vm.ctrlHeld = !vm.ctrlHeld }, CyanBright)
            ModifierToggle("⎇", "Alt", vm.altHeld, { vm.altHeld = !vm.altHeld }, AmberGold)

            Divider(color = LightBorder.copy(alpha = 0.3f), modifier = Modifier.padding(vertical = 2.dp))

            ModifierButton("↩", "Undo") { vm.undo() }
            ModifierButton("↪", "Redo") { vm.redo() }

            Divider(color = LightBorder.copy(alpha = 0.3f), modifier = Modifier.padding(vertical = 2.dp))

            ModifierToggle("✎", "Stylus", vm.stylusOnly, { vm.stylusOnly = !vm.stylusOnly }, PrimaryBlue)
        }
    }
}

@Composable
fun ModifierToggle(
    icon: String, label: String,
    active: Boolean, onClick: () -> Unit,
    activeColor: androidx.compose.ui.graphics.Color
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(8.dp),
        color = if (active) activeColor.copy(alpha = 0.3f) else MidSurface,
        modifier = Modifier.width(48.dp).height(40.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(icon, fontSize = 16.sp,
                color = if (active) activeColor else TextSecondary)
            Text(label, fontSize = 7.sp,
                color = if (active) activeColor else TextMuted)
        }
    }
}

@Composable
fun ModifierButton(icon: String, label: String, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(8.dp),
        color = MidSurface,
        modifier = Modifier.width(48.dp).height(40.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(icon, fontSize = 16.sp, color = TextSecondary)
            Text(label, fontSize = 7.sp, color = TextMuted)
        }
    }
}
