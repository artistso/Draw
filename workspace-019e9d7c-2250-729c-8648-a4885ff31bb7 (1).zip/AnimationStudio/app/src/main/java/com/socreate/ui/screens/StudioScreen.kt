package com.socreate.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.socreate.ui.canvas.PerspectiveCanvas
import com.socreate.ui.theme.SoCreateTheme
import com.socreate.ui.timeline.SpiralTimelineBar
import com.socreate.ui.tools.ToolOrbTray
import com.socreate.ui.tools.ModifierBar
import com.socreate.ui.layers.LayerPanel
import com.socreate.ui.rigging.RiggingPanel

/**
 * Main studio screen — everything comes together here.
 * Full-screen canvas with floating tool orbs, spiral timeline,
 * modifier bar, layer panel, and rigging tools.
 */
@Composable
fun StudioScreen(vm: StudioViewModel = viewModel()) {
    Box(modifier = Modifier.fillMaxSize()) {
        // The perspective canvas fills the screen
        PerspectiveCanvas(
            vm = vm,
            modifier = Modifier.fillMaxSize()
        )

        // Spiral timeline bar at bottom
        SpiralTimelineBar(
            vm = vm,
            modifier = Modifier.align(androidx.compose.ui.Alignment.BottomCenter)
        )

        // Tool orbs — radial menu system
        ToolOrbTray(
            vm = vm,
            modifier = Modifier.align(androidx.compose.ui.Alignment.BottomCenter)
                .padding(bottom = 80.dp)
        )

        // Dedicated Shift/Ctrl/Alt modifier bar (draggable)
        ModifierBar(
            vm = vm,
            modifier = Modifier.align(androidx.compose.ui.Alignment.TopEnd)
                .padding(top = 48.dp, end = 12.dp)
        )

        // Layer panel (toggleable)
        AnimatedVisibility(
            visible = vm.showLayers,
            modifier = Modifier.align(androidx.compose.ui.Alignment.CenterStart)
        ) {
            LayerPanel(vm = vm)
        }

        // Rigging panel (toggleable)
        AnimatedVisibility(
            visible = vm.showRigging,
            modifier = Modifier.align(androidx.compose.ui.Alignment.CenterEnd)
        ) {
            RiggingPanel(vm = vm)
        }
    }
}
