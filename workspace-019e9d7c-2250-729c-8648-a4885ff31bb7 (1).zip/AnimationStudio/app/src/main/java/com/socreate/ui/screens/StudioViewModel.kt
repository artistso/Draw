package com.socreate.ui.screens

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Offset
import com.socreate.engine.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class StudioViewModel {
    val engine = AnimationEngine()

    // Drawing state
    var currentTool by mutableStateOf(DrawingTool.BRUSH)
    var brushSize by mutableStateOf(8f)
    var brushOpacity by mutableStateOf(1f)
    var brushHardness by mutableStateOf(0.8f)
    var currentColor by mutableStateOf(0xFF000000.toInt())
    var stabilizer by mutableStateOf(0.3f)

    // Modifier keys (dedicated toggleable)
    var shiftHeld by mutableStateOf(false)
    var ctrlHeld by mutableStateOf(false)
    var altHeld by mutableStateOf(false)

    // Stylus mode
    var stylusOnly by mutableStateOf(false)

    // Onion
    var onionPrevColor by mutableStateOf(0xFF3b82f6.toInt())
    var onionNextColor by mutableStateOf(0xFFef4444.toInt())

    // Layers
    private val _layers = mutableStateOf(listOf(
        AnimationLayer(0, "Background"),
        AnimationLayer(1, "Line Art"),
        AnimationLayer(2, "Color"),
        AnimationLayer(3, "Effects")
    ))
    val layers by _layers
    var currentLayerIndex by mutableStateOf(1)

    // Frames/keyframes
    val keyframes = mutableSetOf(0, 6, 12, 18)
    val tweenFrames = mutableSetOf<Int>()
    val selectedFrames = mutableSetOf<Int>()

    // Rigging
    var activeRig by mutableStateOf<CharacterRig?>(null)

    // 3D Perspective Box
    var showPerspectiveBox by mutableStateOf(true)
    var perspectiveBoxDepth by mutableStateOf(0.6f)
    var perspectiveBoxRotation by mutableStateOf(0f)

    // Canvas viewport
    var zoom by mutableStateOf(1f)
    var panX by mutableStateOf(0f)
    var panY by mutableStateOf(0f)

    // Grid
    var showGrid by mutableStateOf(false)
    var gridSize by mutableStateOf(64f)
    var gridSnap by mutableStateOf(false)

    // Selection
    var selectionBounds by mutableStateOf<SelectionBounds?>(null)
    var showLayers by mutableStateOf(false)
    var showRigging by mutableStateOf(false)

    // Undo/redo
    private val _undoStack = mutableListOf<UndoState>()
    private val _redoStack = mutableListOf<UndoState>()

    fun currentFrame() = engine.state.currentFrame
    fun totalFrames() = engine.state.totalFrames

    fun goToFrame(i: Int) { engine.goToFrame(i) }
    fun addFrame() { engine.addFrame() }
    fun togglePlay() {
        engine.state = engine.state.copy(isPlaying = !engine.state.isPlaying)
    }

    fun addStroke(stroke: StrokeData) {
        saveUndo()
        _layers.value[currentLayerIndex].addStroke(currentFrame(), stroke)
    }

    fun clearFrame() {
        saveUndo()
        _layers.value.forEach { it.clearFrame(currentFrame()) }
    }

    fun getStrokesForFrame(frame: Int, layerIdx: Int): List<StrokeData> =
        _layers.value.getOrNull(layerIdx)?.getStrokes(frame) ?: emptyList()

    fun toggleKeyframe() {
        val cf = currentFrame()
        if (cf in keyframes) keyframes.remove(cf) else keyframes.add(cf)
    }

    private fun saveUndo() {
        // Snapshot current layer's frame strokes
        val snap = _layers.value.map { layer ->
            val strokes = layer.getStrokes(currentFrame())
            layer.id to strokes.map { it.copy() }
        }.toMap()
        _undoStack.add(UndoState(currentFrame(), currentLayerIndex, snap))
        if (_undoStack.size > 100) _undoStack.removeFirst()
        _redoStack.clear()
    }

    fun undo() {
        val state = _undoStack.removeLastOrNull() ?: return
        // Save redo
        _redoStack.add(UndoState(currentFrame(), currentLayerIndex, emptyMap()))
        // Restore
        // ... (full implementation would restore stroke data)
    }

    fun redo() {
        _redoStack.removeLastOrNull() ?: return
        // Restore redo state
    }

    data class UndoState(
        val frame: Int,
        val layerIndex: Int,
        val snapshot: Map<Int, List<StrokeData>>
    )

    data class SelectionBounds(
        val minX: Float, val minY: Float,
        val maxX: Float, val maxY: Float
    )
}
