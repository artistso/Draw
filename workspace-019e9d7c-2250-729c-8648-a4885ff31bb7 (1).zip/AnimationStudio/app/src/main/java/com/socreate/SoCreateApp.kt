package com.socreate

import android.app.Application

class SoCreateApp : Application() {
    lateinit var engine: com.socreate.engine.AnimationEngine
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this
        engine = com.socreate.engine.AnimationEngine()
    }

    companion object {
        lateinit var instance: SoCreateApp
            private set
    }
}
