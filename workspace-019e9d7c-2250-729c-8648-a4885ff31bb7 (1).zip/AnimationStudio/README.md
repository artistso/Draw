# SoCreate — Professional Animation Studio

**Built for the Samsung Galaxy Tab S10+** and all Android tablets (API 31+).

A fluid, organic animation studio with a 3D perspective workspace, radial tool system, spiral timeline, character rigging, algorithmic tweening, and full pen pressure support. No generative AI. No API calls. Everything local.

---

## Features

### 🎨 3D Perspective Canvas
- Trapezoidal perspective box showing foreground (wide), background (narrow), side walls, and ground plane
- Side tools positioned at natural hand angles
- Grid overlay with adjustable size
- Pinch-to-zoom and pan

### 🖌️ Drawing Engine
- 8 tools: Brush, Pencil, Ink, Airbrush, Eraser, Fill, Lasso, Liquify
- Adaptive stroke stabilizer (One-Euro style)
- Customizable pressure curve remapping
- Size, hardness, opacity, and stabilizer sliders
- 12 color palette chips + color picker

### 🎬 Animation Timeline
- Spiral geodesic timeline — frames spiral outward from center
- Keyframe marking (amber glow)
- Tween frame tracking (cyan glow)
- Play/pause, FPS control (4-60), frame navigation
- Multi-frame selection with Shift+click

### 🔄 Algorithmic Tweening
- 7 easing curves (Smoothstep, Linear, Ease In/Out, Ease In-Out, Bounce, Elastic)
- Stroke interpolation with point resampling and color blending
- Bulk tweening between selected keyframe pairs

### 👻 Onion Skinning
- Color-coded previous/next frames
- Configurable count (1-6)
- Per-frame opacity control

### 🦴 Character Rigging
- Auto-rig humanoid skeleton detection
- 10-joint, 9-bone skeleton structure
- IK targets for inverse kinematics
- Bone overlay on canvas
- Toggleable rig visibility

### ⌨️ Dedicated Modifier Bar
- Toggleable Shift, Ctrl, Alt buttons
- Undo/Redo with history
- Stylus-only mode toggle
- Designed for the animator's non-drawing hand

### 📑 Layer System
- Reorderable layer panel
- Per-layer visibility toggle
- Frame-specific stroke storage

### 💾 Project Management
- Save/load projects as `.socreate` JSON files
- Project gallery
- Export as image sequence

### 🔊 Audio Support
- Drag-and-drop MP3/WAV import
- Waveform display on timeline
- Play/pause audio during animation preview

---

## Architecture

```
SoCreate/
├── app/
│   ├── build.gradle.kts
│   ├── proguard-rules.pro
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/socreate/
│       │   ├── SoCreateApp.kt          # Application class
│       │   ├── MainActivity.kt         # Entry point
│       │   ├── engine/
│       │   │   ├── AnimationEngine.kt  # Core animation + spring physics
│       │   │   └── StrokeData.kt       # Stroke/Layer/Frame models
│       │   └── ui/
│       │       ├── canvas/
│       │       │   └── PerspectiveCanvas.kt  # 3D perspective box canvas
│       │       ├── layers/
│       │       │   └── LayerPanel.kt        # Layer management
│       │       ├── rigging/
│       │       │   └── RiggingPanel.kt      # Character rigging tools
│       │       ├── screens/
│       │       │   ├── StudioScreen.kt      # Main screen composition
│       │       │   └── StudioViewModel.kt   # State management
│       │       ├── theme/
│       │       │   └── Theme.kt             # Color system
│       │       ├── timeline/
│       │       │   └── SpiralTimelineBar.kt # Spiral timeline
│       │       └── tools/
│       │           ├── ToolOrbTray.kt       # Radial orb menu system
│       │           └── ModifierBar.kt       # Shift/Ctrl/Alt bar
│       └── res/values/
│           ├── strings.xml
│           └── themes.xml
├── build.gradle.kts
├── settings.gradle.kts
├── gradle.properties
└── README.md
```

## Build

```bash
cd SoCreate
./gradlew assembleDebug
```

### Prerequisites
- Android Studio Hedgehog (2023.1+) or later
- JDK 17
- Android SDK 34
- Gradle 8.5+

### Requirements
- Android 12+ (API 31)
- 4GB+ RAM recommended
- S Pen or active stylus for pressure sensitivity
- Optimized for large screens (Tab S10+)

## Keyboard Shortcuts

| Key | Action |
|-----|--------|
| B / P / I / A / E / S / L | Switch tools |
| ← → | Navigate frames |
| Space | Play/Pause |
| K | Toggle keyframe |
| O | Toggle onion skin |
| G | Toggle grid |
| V | Toggle perspective box |
| Ctrl+A | Select all strokes |
| Ctrl+Z / Ctrl+Y | Undo/Redo |
| Ctrl+D | Duplicate frame |
| Ctrl+Wheel | Brush size |
| Delete | Delete selection |
| Arrow keys | Nudge selection |

---

*Built for creators. No AI generation. No cloud. No telemetry. Just tools.*
