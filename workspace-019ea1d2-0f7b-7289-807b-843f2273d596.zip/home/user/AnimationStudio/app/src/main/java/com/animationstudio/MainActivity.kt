package com.animationstudio

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.core.view.WindowCompat
import androidx.lifecycle.ViewModelProvider
import com.animationstudio.ui.screens.MainScreen
import com.animationstudio.ui.theme.AnimationStudioTheme
import com.animationstudio.ui.theme.rememberWindowSizeClass

class MainActivity : ComponentActivity() {

    private lateinit var mainViewModel: MainViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)

        // Full immersive mode for drawing
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        mainViewModel = ViewModelProvider(this)[MainViewModel::class.java]

        // Handle any incoming intents
        handleIntent(intent)

        setContent {
            val windowSizeClass = rememberWindowSizeClass()

            AnimationStudioTheme(windowSizeClass = windowSizeClass) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    val app = remember { AnimationApp.instance }
                    MainScreen(
                        viewModel = mainViewModel,
                        database = app.database,
                        aiModelManager = app.aiModelManager,
                        animationEngine = app.animationEngine,
                        windowSizeClass = windowSizeClass
                    )
                }
            }
        }
    }

    private fun handleIntent(intent: android.content.Intent) {
        when {
            intent.action == android.content.Intent.ACTION_VIEW -> {
                intent.data?.let { uri ->
                    mainViewModel.handleFileOpen(uri)
                }
            }
        }
    }
}